# set up and installation in physiCell
cd PhysiCell_path
git clone git-url
cp physimorph/Makefile .
make morph
make


# ellipsoid cells

## still needed

- [ ] test elipsoids as matrix
- [ ] test rotate with matrix
- [ ] rotate in SVG
- [ ] neighboors interact along "deepest point of overlap"
- [ ] uptake/secretion
- [ ] elongation function

also, have to fix the color blind mode in the custom svg handling

ideas:
- [ ] make a function that determines the voxels along some path f(x,y,z)
- play with 4-axis
- add vector version
- take in rotations
